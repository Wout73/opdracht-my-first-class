﻿
namespace StoelProject
{
    internal class Program
    {
        // Methode om de eigenschappen van de stoel in te stellen of aan te passen
        static void StoelInstellingen(ref string kleur, ref int hoogte)
        {
            try
            {
                Console.WriteLine("\n--- STOEL INSTELLEN ---");
                Console.WriteLine("Voer de kleur in (bijv. Red, Blue, Green, Yellow, White):");
                kleur = Console.ReadLine();

                Console.WriteLine("Voer de hoogte in cm in:");
                hoogte = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Stoel succesvol ingesteld!");
            }
            catch
            {
                Console.WriteLine("Fout: Ongeldige invoer!");
            }
        }

        // Methode om de stoel te tonen in de gekozen kleur
        static void ToonStoel(string kleur, int hoogte)
        {
            try
            {
                // Probeer de consolekleur in te stellen op basis van de ingevoerde kleur
                if (Enum.TryParse(kleur, true, out ConsoleColor consoleColor))
                {
                    Console.ForegroundColor = consoleColor;
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
            catch
            {
                Console.ForegroundColor = ConsoleColor.White;
            }

            Console.WriteLine("\n-------------------------");
            Console.WriteLine($"Kleur van de stoel: {kleur}");
            Console.WriteLine($"Hoogte van de stoel: {hoogte} cm");
            Console.WriteLine("-------------------------");

            // Reset de consolekleur naar de standaardkleur
            Console.ResetColor();
        }

        static void Main(string[] args)
        {
            bool actief = true;
            string stoelKleur = "White";
            int stoelHoogte = 50;

            while (actief)
            {
                Console.WriteLine("\n1. Stoel instellen / aanpassen");
                Console.WriteLine("2. Toon stoel");
                Console.WriteLine("3. Clean (Scherm opschonen)");
                Console.WriteLine("4. Afsluiten");
                Console.Write("Maak een keuze: ");

                try
                {
                    int keuze = Convert.ToInt32(Console.ReadLine());

                    if (keuze == 1)
                    {
                        StoelInstellingen(ref stoelKleur, ref stoelHoogte);
                    }
                    else if (keuze == 2)
                    {
                        ToonStoel(stoelKleur, stoelHoogte);
                    }
                    else if (keuze == 3)
                    {
                        Console.Clear();
                    }
                    else if (keuze == 4)
                    {
                        actief = false;
                        Console.WriteLine("Programma wordt afgesloten...");
                    }
                    else
                    {
                        Console.WriteLine("Fout: Kies een getal tussen 1 en 4.");
                    }
                }
                catch
                {
                    Console.WriteLine("Fout: Ongeldige invoer! Voer een getal in.");
                }
            }
        }
    }
}